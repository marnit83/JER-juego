// var imported = document.createElement('phaser');
// imported.src = '../phaser.min.js';
// document.head.appendChild(imported);

//document.writeln("<script type='text/javascript' src='../phaser.min.js'></script>");

// var x = document.createElement('script');
// x.src = '../phaser.min.js';
// document.getElementsByTagName("head")[0].appendChild(x);
//$.getScript('../phaser.min.js', PreloadEscenario());
class Arte extends Phaser.Scene{
    constructor(){
        super({key:"Arte"});
    }
    create(){
        alert("se ha cargado la escena A");
    }
}
function PreloadEscenario(){
    this.load.image('sky', './Assets/sky.png');
    this.load.image('ground', './Assets/platform.png');
    this.load.image('star', './Assets/star.png');
    this.load.image('bomb', './Assets/bomb.png');
    this.load.spritesheet('dude', 
        './Assets/dude.png',
        { frameWidth: 32, frameHeight: 48 }
    );
};

function CreateEscenario(){
    this.add.image(400, 300, 'sky');
    this.add.image(400, 300, 'star');
};