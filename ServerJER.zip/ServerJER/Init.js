// import Arte from "./Arte";
// import Jugador from "./Jugador";

const config = {
    type: Phaser.AUTO,
    width:1420,
    height:600,
    parent:"container",
    scene: [Arte, Jugador]
};

var game = new Phaser.Game(config);

function preload ()
{
    PreloadEscenario();
    // this.load.image('sky', 'Assets/sky.png');
    // this.load.image('ground', 'Assets/platform.png');
    // this.load.image('star', 'Assets/star.png');
    // this.load.image('bomb', 'Assets/bomb.png');
    // this.load.spritesheet('dude', 
    //     'Assets/dude.png',
    //     { frameWidth: 32, frameHeight: 48 }
    // );
}

function create ()
{
    CreateEscenario();
    CreatePlayer();
}

function update ()
{
    
}

